const express = require('express');
const router = express.Router();

const fs = require('fs');
const path = require('path');

router.post('/', (req, res) => {
    const { fname, lname, occupation_category, occupation, email, password } = req.body;
    const user = { createdAt: new Date(), fname, lname, occupation_category, occupation, email, password };
    const filePath = path.join(__dirname, '..', 'data', 'user.json');

    let users = [];

    try {
        if (fs.existsSync(filePath)) {
            const filedata = fs.readFileSync(filePath, 'utf-8').trim();

            if (filedata) {
                users = JSON.parse(filedata);
            }
        }

        const emailExists = users.some(u => u.email === email);
        if (emailExists) {
            return res.status(400).json({ error: "this email has already been used" });
        }

        users.push(user);
        fs.writeFileSync(filePath, JSON.stringify(users, null, 2));

        console.log('Content from submitted', { fname, lname, occupation_category, occupation, email, password });
        res.status(200).json({ status: "Message Received" });

    } catch (error) {
        console.error('Error handling user data:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

module.exports = router;
