const express = require('express');
const router = express.Router();

const fs = require('fs');
const path = require('path');

// POST /api/login
router.post('/', (req, res) => {
    const { username, password } = req.body;

    const filePath = path.join(__dirname, '../data/user.json');

    fs.readFile(filePath, 'utf8', (err, jsonData) => {
        if (err) {
            console.error('อ่านไฟล์ไม่สำเร็จ:', err);
            return res.status(500).json({ message: 'เกิดข้อผิดพลาดภายในเซิร์ฟเวอร์' });
        }

        let users;
        try {
            users = JSON.parse(jsonData);
        } catch (parseErr) {
            console.error('แปลง JSON ไม่สำเร็จ:', parseErr);
            return res.status(500).json({ message: 'ข้อมูลผู้ใช้ผิดพลาด' });
        }

        const user = users.find(u => u.email === username);

        if (!user) {
            return res.status(401).json({ message: 'Incorrected Username' });
        }

        if (user.password !== password) {
            return res.status(401).json({ message: 'Incorrected Password.' });
        }

        return res.status(200).json({ message: 'Login successfully.' });
    });
});

module.exports = router;
